java 	 python	  c 	       c++
html 	 css 	  js	       php
git      jupyter  haskell      blender
vhdl     binary   electronics  shell